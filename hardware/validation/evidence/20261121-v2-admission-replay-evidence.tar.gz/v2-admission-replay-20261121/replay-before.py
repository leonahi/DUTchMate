"""Replay frozen UART events into a new store; never opens a serial device."""
import argparse
import base64
from collections import deque
import cProfile
from dataclasses import replace
from datetime import datetime, timezone
import hashlib
import io
import json
from pathlib import Path
import pstats
from threading import Event
import time

from dutchmate_core.backends import (
    BackendCapabilityPolicy, BackendDisconnectedError, BackendInfo,
    BackendSnapshot, SegmentContext, SegmentTimestamp, UartIntegrity,
    UartReceiveEvent, UartSendCapabilityPolicy,
)
from dutchmate_core.evidence.recorder import ContinuousEvidenceRecorder
from dutchmate_core.profile import resolve_dut_profile, load_dut_profile_config
from dutchmate_core.session_store.store import SessionStore


class ReplaySource:
    def __init__(self, events, segment, profiler):
        self.events = deque(events)
        self.segment = segment
        self.profiler = profiler
        self.started = None
        self.elapsed = None
        self.finished = Event()
        self.closed = Event()

    @property
    def has_pending_events(self):
        return bool(self.events)

    def read_event(self):
        if self.started is None:
            self.started = time.monotonic()
            if self.profiler:
                self.profiler.enable()
        if self.events:
            return self.events.popleft()
        if not self.finished.is_set():
            if self.profiler:
                self.profiler.disable()
            self.elapsed = time.monotonic()-self.started
            self.finished.set()
        self.closed.wait()
        raise BackendDisconnectedError('offline replay closed')

    def close(self):
        self.closed.set()


parser = argparse.ArgumentParser()
parser.add_argument('--run', required=True)
parser.add_argument('--limit', type=int)
parser.add_argument('--profile', action='store_true')
args = parser.parse_args()
root = Path(__file__).resolve().parents[1]
original = root/'.dutchmate/hil/kicad-rev-a-boot-20261120/run/.dutchmate/sessions/20261120T180241Z-21d9dc70'
meta = json.loads((original/'metadata.json').read_text())
events = [UartReceiveEvent(0, r['timestamp_us'], r['channel'], base64.b64decode(r['data_b64'], validate=True))
          for r in map(json.loads, (original/'uart_events.jsonl').read_text().splitlines())
          if r['raw_offset_start'] >= 345]
if args.limit:
    events = events[:args.limit]
expected = b''.join(e.data for e in events)
assert expected == (original/'uart_raw.log').read_bytes()[345:345+len(expected)]
original_hashes = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in original.iterdir() if p.is_file()}
out = root/'.dutchmate/diagnostics/20261121-admission-replay'/args.run
out.mkdir(parents=True, exist_ok=False)
profile = resolve_dut_profile(load_dut_profile_config(original.parents[1]/'config.toml'), serial_port='/offline/replay')
segment = SegmentContext(0, SegmentTimestamp(**meta['segments'][1]['timestamp']))
info = BackendInfo(mode='enhanced', port='/offline/replay', device='dutchmate-rp2350', firmware='gp28safe-1',
                   capabilities=frozenset(meta['segments'][1]['backend']['capabilities']))
snapshot = BackendSnapshot(info=info, capabilities=info.capabilities,
    capability_policy=BackendCapabilityPolicy(uart_send=UartSendCapabilityPolicy(tx_policy_enabled=True)),
    segment=segment, integrity=UartIntegrity('none_reported', 'debug_helper_rx_buffer', 0))
profiler = cProfile.Profile() if args.profile else None
source = ReplaySource(events, segment, profiler)
store = SessionStore(root=out/'sessions')
recorder = ContinuousEvidenceRecorder(source=source, session_store=store, profile=profile, backend_snapshot=snapshot)
try:
    assert source.finished.wait(120), 'bounded offline replay timed out'
finally:
    recorder.close()
paths = list((out/'sessions').glob('*/uart_raw.log'))
actual = b''.join(p.read_bytes() for p in sorted(paths))
assert actual == expected
assert original_hashes == {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in original.iterdir() if p.is_file()}
report = {'utc': datetime.now(timezone.utc).isoformat(), 'run': args.run, 'profiled': args.profile,
          'events': len(events), 'raw_bytes': len(expected), 'raw_sha256': hashlib.sha256(expected).hexdigest(),
          'elapsed_s': source.elapsed, 'source_stream_span_s': (events[-1].timestamp_us-events[0].timestamp_us)/1e6,
          'original_unchanged': True, 'output_exact': True,
          'source_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
if profiler:
    profiler.dump_stats(str(out/'ingestion.prof'))
    buffer = io.StringIO()
    pstats.Stats(profiler, stream=buffer).strip_dirs().sort_stats('cumulative').print_stats(35)
    (out/'profile.txt').write_text(buffer.getvalue())
    print(buffer.getvalue())
(out/'result.json').write_text(json.dumps(report, indent=2)+'\n')
print(json.dumps(report, indent=2), flush=True)
